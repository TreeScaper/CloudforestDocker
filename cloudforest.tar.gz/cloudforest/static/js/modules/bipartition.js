
let bipartition_bar_chart = function (config) {
    let {
        subscribe,
        publish,
        main_div,
        guid_func
    } = config;

    let data_files = undefined;

    const list_to_dictionary = function (lst) {
        let partitions = {};
        lst.map(function (row) {
            let k = `Partition ${row[0] + 1}`;
            if (Object.keys(partitions).indexOf(k) == -1) {
                partitions[k] = [];
            }
            partitions[k].push(row[1]);
        });
        return partitions;
    }

    const bipart_log_parse = function (lines) {
        console.log(lines);
        let taxa_flag = false;
        let taxa = [];
        let bipartitions = [];
        lines.forEach(e => {
            const entry = e[0]; //TODO: this needs fixing.
            if (entry.toLocaleLowerCase().startsWith("translation of taxa")) {
                taxa_flag = true;
            }
            if (entry.toLocaleLowerCase().startsWith("bipartition")) {
                taxa_flag = false;
            }
            if (taxa_flag && !(entry.toLocaleLowerCase().startsWith("translation of taxa"))) {
                taxa.push(entry.split(',')[0].trim());
            }
            if (entry.toLocaleLowerCase().startsWith("bipartition")) {
                let f = entry.split(":");
                let b = f[1].split(",")[0].trim();
                bipartitions.push(b.split('').map(v => {
                    return Number(v)
                }));
            }
        });
        return {
            'taxa_keys': taxa,
            'bipartitions': bipartitions
        }
    }

    let build_dom = function () {
        // Parse bipartition log to get list of partitions and taxa.
        let bipartitions = bipart_log_parse(data_files.log_file.contents);

        //let lst = [];
        // d3.tsvParseRows(data_files.data_file.contents, function (row) {
        //     lst.push(row.map(x => Number(x)));
        // });
        let chart_data = list_to_dictionary(data_files.data_file.contents);

        function sort_fn(a, b) {
            let first = Number(a.split(/\W/)[1]);
            let second = Number(b.split(/\W/)[1]);
            return first - second;
        }
        let sorted_keys = Object.keys(chart_data);
        sorted_keys.sort(sort_fn);
        let data = [{
            x: sorted_keys,
            y: sorted_keys.map(k => {
                return chart_data[k].length;
            }),
            type: 'bar'
        }];
        let layout = {
            width: 1200,
            height: 600,
            title: 'Presence of Partitions in Trees',
            xaxis: {
                tickangle: -45
            },
            yaxis: {
                title: 'Number of Trees Present'
            },
        };
        publish("ShowingVisualization", { name: "bipartition" });
        document.getElementById(main_div).setAttribute("style", "display:block");
        let bp_plot = document.getElementById("bipartition_chart");
        Plotly.newPlot("bipartition_chart", data, layout, {
            displaylogo: false
        });
        bp_plot.on("plotly_click", function (data) {
            let p_idx = data.points[0]['pointIndex']
            let in_part = [];
            let out_part = [];
            bipartitions["bipartitions"][p_idx].forEach((element, idx) => {
                if (element) {
                    in_part.push(bipartitions['taxa_keys'][idx]);
                } else {
                    out_part.push(bipartitions['taxa_keys'][idx]);
                }
            });
            document.getElementById("in_partition").innerHTML = `In partition ${p_idx + 1}: ${in_part.join(', ')}`;
            document.getElementById("out_partition").innerHTML = `Out partition ${p_idx + 1}: ${out_part.join(', ')}`;
        });
    }

    const init = function () {
        //Pub Sub Section
        const msg_guid = guid_func();
        const file_name_regex = /[bB]ipartition|BipartionLog/;
        subscribe("AvailableFiles", data => {
            if (data.guid === msg_guid) {
                const regex = RegExp(file_name_regex);
                let coor_files = data.data.filter(f => {
                    return regex.test(f);
                });

                subscribe("FileContents", d => {
                    if (d.guid != msg_guid) {
                        return;
                    }
                    let df = {}
                    coor_files.forEach(k => {
                        if (k.indexOf("BipartionLog") > -1) {
                            df["log_file"] = {
                                "name": k,
                                "contents": d.files_object[k]
                            };
                        } else {
                            df["data_file"] =
                            {
                                "name": k,
                                "contents": d.files_object[k]
                            };
                        }
                    });
                    data_files = df;

                    build_dom();
                });
                if (coor_files.length > 0) {
                    publish("RequestFileContents", {
                        guid: msg_guid,
                        names: coor_files
                    });
                }
            }
        });
        publish("AvailableFilesRequest", { guid: msg_guid });
    };
    return { init };
}

export { bipartition_bar_chart }