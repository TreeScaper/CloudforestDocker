import { htmlToElement } from "./html_template.js";

/**
 * Create line plots illustrating community plateaus
 */

let community_plots = function (conf_obj) {

    const { subscribe, publish, two_d_dom, three_d_dom, main_div, guid_func } = conf_obj;

    const init = function () {
        const msg_guid = guid_func();
        const file_name_regex = /[Cc]ommunity|[Rr]results/;
        subscribe("AvailableFiles", data => {
            if (data.guid === msg_guid) {
                const regex = RegExp(file_name_regex);
                let plotting_files = data.data.filter(f => {
                    return regex.test(f);
                });

                subscribe("FileContents", d => {
                    if (d.guid === msg_guid) {
                        let df = {};
                        plotting_files.forEach(k => {
                            df[k] = d.files_object[k];
                        });
                        //Preprocess data??
                        let processed_data = process_data(df); //TODO: create this method
                        build_dom({});
                    }
                });
                if (plotting_files.length > 0) {
                    publish("RequestFileContents", {
                        guid, msg_guid,
                        names: plotting_files
                    })
                } else {
                    publish("ModuleLoaded", {}); // No files of interest, publish and forget
                }
            }
        });

    };

    return { init };

}

export { community_plots }