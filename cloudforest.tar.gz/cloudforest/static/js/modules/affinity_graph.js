import { htmlToElement } from "./html_template.js";

let plot_affinity_graph = function (conf_obj) {
    const { subscribe, publish, guid_func, main_div } = conf_obj;
    let data_files = undefined;

    const aggreagate_test = function (source, target, sets) {
        let needs_agg = true;
        sets.forEach(s => {
            if (s.has(source) || s.has(target)) {
                s.add(source);
                s.add(target);
                needs_agg = false;
            }
        });
        if (needs_agg) {
            let new_set = new Set();
            new_set.add(source);
            new_set.add(target);
            sets.push(new_set);
        }
    }

    const generate_matrix = function (m) {

        let link_groups = [new Set()]; //Use to group nodes into aggregated sets based on links.
        let json_data = {
            "nodes": [],
            "links": []
        };
        let ids = [];
        m.forEach((element, idx) => {
            if (idx > 0) {
                json_data["nodes"].push({
                    "id": String(element[0]),
                    "group": "99"
                });
                ids.push(String(element[0]));
            }

        });
        m.forEach((element, idx) => {
            if (idx > 0) {
                let source = element[0];
                element.splice(1).forEach((e, i) => {
                    if (e.length > 0) {
                        let target = ids[i];
                        let value = Number(e);
                        if (source != target && value >= 1.0) {
                            aggreagate_test(source, target, link_groups);
                            json_data["links"].push({
                                "source": source,
                                "target": target,
                                "value": value
                            });
                        }
                    }
                });
            }
        });

        //set group id for nodes based on aggregation
        json_data.nodes.forEach(n => {
            link_groups.forEach((g, idx) => {
                for (let item of g) {
                    if (n.id === item) {
                        n["group"] = String(idx);
                    }
                }
            });
        });

        return json_data;
    }

    const draw_force_graph = function (graph, div_id) {
        const canvas_div = div_id;
        let flatten_group = function (obj) {
            let r_val = {};
            obj.nodes.forEach(n => {
                r_val[n.id] = n.count;
            });
            return r_val;
        }
        let group_counts = flatten_group(build_ballon_nodes(graph.nodes));

        let canvas = document.getElementById(canvas_div),
            ctx = canvas.getContext('2d'),
            width = canvas.getAttribute("width"),
            height = canvas.getAttribute("height"),
            r = 5,
            color = d3.scaleSequential(d3.interpolatePiYG);

        let simulation = d3.forceSimulation()
            .force("x", d3.forceX(width / 2))
            .force("y", d3.forceY(height / 2))
            .force("collide", d3.forceCollide(r + 2))
            .force("charge", d3.forceManyBody().strength(-10))
            .force("link", d3.forceLink()
                .id(function (d) { return d.id; }).distance(30));

        function dragsubject() {
            return simulation.find(d3.event.x, d3.event.y);
        }

        d3.select(canvas)
            .call(d3.drag()
                .container(canvas)
                .subject(dragsubject)
                .on("start", dragstarted)
                .on("drag", dragged)
                .on("end", dragended));

        simulation.nodes(graph.nodes)
            .on("tick", update);
        simulation.force("link")
            .links(graph.links);

        function update() {
            ctx.clearRect(0, 0, width, height);

            ctx.beginPath();
            ctx.globalAlpha = 0.2;
            ctx.strokeStyle = "#aaa";
            graph.links.forEach(drawLink);
            ctx.stroke();

            ctx.globalAlpha = 1.0;
            graph.nodes.forEach(drawNode);
        }

        function drawNode(d) {
            ctx.beginPath();
            ctx.fillStyle = color(Number(d.group) / 10);
            ctx.moveTo(d.x, d.y);
            ctx.arc(d.x, d.y, r, 0, Math.PI * 2);
            ctx.fill();
        }

        function drawLink(l) {
            ctx.moveTo(l.source.x, l.source.y);
            ctx.lineTo(l.target.x, l.target.y);
        }

        function dragstarted() {
            if (!d3.event.active) simulation.alphaTarget(0.3).restart();
            d3.event.subject.fx = d3.event.subject.x;
            d3.event.subject.fy = d3.event.subject.y;
        }

        function dragged() {
            d3.event.subject.fx = d3.event.x;
            d3.event.subject.fy = d3.event.y;
        }

        async function dragended() {
            if (!d3.event.active) simulation.alphaTarget(0);
            d3.event.subject.fx = null;
            d3.event.subject.fy = null;
            let gid = d3.event.subject.group;
            ctx.beginPath();
            ctx.fillStyle = "black";
            ctx.globalAlpha = 0.5;
            ctx.fillRect(d3.event.subject.x - 10, d3.event.subject.y - 30, 200, 50);
            ctx.globalAlpha = 1.0;
            ctx.fillStyle = "white";
            ctx.font = "bold 15px Arial";
            ctx.fillText(`Group: ${gid} Tree Count: ${group_counts[gid]}`, d3.event.subject.x, d3.event.subject.y, 200);
            simulation.stop();
            await new Promise(r => setTimeout(r, 3000));
            simulation.restart();
        }

        update();
    }

    const draw_ballon_graph = function (b_nodes, div_id) {
        let canvas = document.getElementById(div_id),
            ctx = canvas.getContext('2d'),
            width = canvas.getAttribute("width"),
            height = canvas.getAttribute("height"),
            color = d3.scaleSequential(d3.interpolatePiYG);

        let ballon_sim = d3.forceSimulation()
            .force("collide", d3.forceCollide(d => d.count + 5).iterations(12))
            .force("charge", d3.forceManyBody())
            .velocityDecay(0.75)
            .alphaDecay(0.006)
            .force("center", d3.forceCenter(width / 2, height / 2))
            .force("y", d3.forceY(0))
            .force("x", d3.forceX(0));

        let b_update = function () {
            ctx.clearRect(0, 0, width, height);
            b_nodes.forEach(draw_b_node);
        }

        let draw_b_node = function (d) {
            ctx.beginPath();
            ctx.fillStyle = color(d.id / 10);
            ctx.moveTo(d.x, d.y);
            ctx.arc(d.x, d.y, d.count, 0, Math.PI * 2);
            ctx.fill();
            if (d.count > 10) {
                ctx.fillStyle = "black";
                ctx.font = "bold 12px Arial";
                ctx.fillText(`Group: ${d.id} - Tree Count: ${d.count}`, d.x - (d.count / 3), d.y);
            }
        }

        let dragstarted = function () {
            if (!d3.event.active) ballon_sim.alphaTarget(0.3).restart();
            d3.event.subject.fx = d3.event.subject.x;
            d3.event.subject.fy = d3.event.subject.y;
        }

        let dragged = function () {
            d3.event.subject.fx = d3.event.x;
            d3.event.subject.fy = d3.event.y;
        }

        let dragended = async function () {
            if (!d3.event.active) ballon_sim.alphaTarget(0);
            d3.event.subject.fx = null;
            d3.event.subject.fy = null;
            if (d3.event.subject.count <= 10) {
                ctx.beginPath();
                ctx.fillStyle = "black";
                ctx.font = "bold 12px Arial";
                ctx.fillText(`Group: ${d3.event.subject.id} - Tree Count: ${d3.event.subject.count}`, d3.event.subject.x, d3.event.subject.y);
            }
            ballon_sim.stop();
            await new Promise(r => setTimeout(r, 3000));
            ballon_sim.restart();
        }

        let dragsubject = function () {
            return ballon_sim.find(d3.event.x, d3.event.y);
        }
        ballon_sim.nodes(b_nodes).on("tick", b_update);
        d3.select(canvas)
            .call(d3.drag()
                .container(canvas)
                .subject(dragsubject)
                .on("start", dragstarted)
                .on("drag", dragged)
                .on("end", dragended));

    }

    const build_ballon_nodes = function (nodes) {
        let r_val = { nodes: [] };

        let new_nodes = {};
        nodes.forEach(n => {
            if (!(n.group in new_nodes)) {
                new_nodes[n.group] = { "id": n.group, "count": 0 };
            }
            new_nodes[n.group]["count"] += 1;
        });
        Object.keys(new_nodes).forEach(k => {
            r_val['nodes'].push(new_nodes[k]);
        });
        return r_val;
    }

    const build_dom = function () {
        let graph = generate_matrix(data_files.data_file.contents)
        console.log(graph);
        draw_force_graph(graph, "network");
        let ballon_nodes = build_ballon_nodes(graph.nodes);
        console.log(ballon_nodes.nodes);
        draw_ballon_graph(ballon_nodes.nodes, "ballons");
        document.getElementById(main_div).setAttribute("style", "display:block");
        publish("ShowingVisualization", { hrefname: "affinity-card", innername: "Affinity Plots" });
        publish("ModuleLoaded", {});
    }

    const init = function () {
        //Pub Sub Section
        let msg_guid = guid_func();
        const file_name_regex = /Affinity/;
        subscribe("AvailableFiles", data => {
            if (data.guid === msg_guid) {
                const regex = RegExp(file_name_regex);
                let coor_files = data.data.filter(f => {
                    return regex.test(f);
                });

                subscribe("FileContents", d => {
                    if (d.guid != msg_guid) {
                        return;
                    }
                    let df = {}
                    coor_files.forEach(k => {
                        if (k.endsWith("log")) {
                            df["log_file"] = {
                                "name": k,
                                "contents": d[k]
                            };
                        } else {
                            df["data_file"] =
                            {
                                "name": k,
                                "contents": d.files_object[k]
                            };
                        }
                    });
                    data_files = df;
                    build_dom();
                });
                if (coor_files.length > 0) {
                    publish("RequestFileContents", {
                        guid: msg_guid,
                        names: coor_files
                    });
                } else {
                    publish("ModuleLoaded", {}); // no files or interest, publish and forget
                }
            }
        });
        publish("AvailableFilesRequest", { guid: msg_guid });
    };

    return { init };
}
export { plot_affinity_graph }