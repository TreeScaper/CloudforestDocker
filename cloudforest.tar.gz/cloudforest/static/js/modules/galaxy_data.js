let galaxy_data_provider = function (conf_obj) {
    let { subscribe, publish, data_name, history_id, dataset_id } = conf_obj;

    const api_key = 'admin';
    let s_api_call = `http://localhost:8080/api/histories/${history_id}/contents?key=${api_key}`;
    let cloudforest_files = undefined;

    function api_fetch(obj) {
        let { api_call, callback_fn, supplemental } = obj;
        return function () {
            fetch(api_call)
                .then(response => {
                    return response.text();//json();
                })
                .then(data => {
                    callback_fn(data, supplemental);
                })
                .catch(function (error) {
                    console.log(`We have an error ${error}`);
                });
        }
    };

    const string_parser = function (s) {
        const split_data = s.split(/\r?\n|\r/g).filter(v => v.length > 0);
        const parsed_data = split_data.map(d => {
            let t = d.trim();
            return t.split('\t');
        });
        return parsed_data;
    };

    const filter_data = function (raw_data) {
        const data = JSON.parse(raw_data);
        const filename_check = function (name) {
            let r_val = false;

            if (name.endsWith("nhx")) {
                r_val = true;
            }
            if (name.endsWith("nex")) {
                r_val = true;
            }
            if (name.endsWith("newick")) {
                r_val = true;
            }
            if (name.endsWith("nexus")) {
                r_val = true;
            }

            return r_val;
        };
        const filetype_check = function (ext) {
            let r_val = false;
            switch (ext) {
                case 'cloudforest':
                case 'nhx':
                case 'nexus':
                case 'nex':
                case 'newick':
                    r_val = true;
                    break;
            }
            return r_val;
        };
        let r_val = data.filter(obj => {
            return (filetype_check(obj.extension) || filename_check(obj.name)) && obj.state === 'ok' && !obj.deleted;
        });
        return r_val;
    };

    const file_names = function () {
        let r_val = [];
        cloudforest_files.forEach(f_obj => {
            r_val.push(f_obj.name);
        });
        return r_val;
    };

    subscribe("AvailableFilesRequest", (d) => {
        let obj = {
            guid: d.guid,
            data: file_names(),
        };
        publish("AvailableFiles", obj);
    });

    subscribe("RequestFileContents", d => {
        let contents = {
            guid: d.guid
        };

        let requested_objs = [];
        cloudforest_files.forEach(f_obj => {
            if (d.names.indexOf(f_obj.name) >= 0) {
                requested_objs.push(f_obj)
            }
        });

        let funcs = [];
        requested_objs.forEach(f_obj => {
            let api_url = `http://localhost:8080${f_obj.url}/display?key=${api_key}`
            funcs.push(
                fetch(api_url)
                    .then(r => { return r.text(); })
                    .then(d => {
                        return { name: f_obj.name, body: string_parser(d) };
                    })
            );
        });
        Promise.all(funcs).then((data) => {
            let o = {};
            data.forEach(entry => {
                o[entry.name] = entry.body;
            });
            contents['files_object'] = o;
            //console.log(contents);
            publish('FileContents', contents);
        });
    });

    const process_history_contents = function (data) {
        let f_data = filter_data(data);
        cloudforest_files = f_data;
        publish("DataPrimed", {});
    };

    const init = function () {
        api_fetch({ api_call: s_api_call, callback_fn: process_history_contents })();
    };

    return { init };
}

export { galaxy_data_provider }