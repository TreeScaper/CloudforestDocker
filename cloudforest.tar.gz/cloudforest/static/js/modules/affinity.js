import { htmlToElement } from "./html_template.js";

let plot_affinity_network = function (conf_obj) {
    const { subscribe, publish, guid_func, main_div } = conf_obj;
    const file_name_regex = /[Aa]ffinity/;
    let data_files = undefined;
    let link_groups = [new Set()];

    let aggregate_test = function (source, target, sets) {
        let needs_agg = true;
        sets.forEach(s => {
            if (s.has(source) || s.has(target)) {
                s.add(source);
                s.add(target);
                needs_agg = false;
            }
        });
        if (needs_agg) {
            let new_set = new Set();
            new_set.add(source);
            new_set.add(target);
            sets.push(new_set);
        }
    }

    let build_nodes_links = function (arr) {
        let links = [];
        arr.forEach(row => {
            let source = row[0].trim();
            row.forEach((cv, idx) => {
                if (idx > 0) {
                    let value = Number(cv.trim());
                    if (value === 1 || value === 10) {
                        let target = String(idx);
                        aggregate_test(source, target, link_groups);
                        links.push({
                            "source": source,
                            "target": target
                        })
                    }
                }
            })
        });
    }

    let build_treemap_data = function () {
        let d = { name: "Trees", children: [] };
        link_groups.forEach((s, idx) => {
            let values = [];
            s.forEach(i => { values.push(i) })
            if (s.size > 0) {
                let o = {
                    name: `Group ${idx}`,
                    value: s.size,
                    members: values
                }
                d.children.push(o);
            }
        });
        return d;
    }

    let build_member_list = function (data) {
        let { arr, name } = data;
        const intro = htmlToElement(`<span>Member Trees for ${name} : </span>`);
        let el = document.getElementById("ag_membership")
        while (el.firstChild) {
            el.removeChild(el.firstChild);
        }
        el.append(intro);
        arr.forEach((e, idx) => {
            if (idx % 30 === 0) {
                el.append(htmlToElement('<br/>'));
            }
            el.append(htmlToElement(`<span class="ml-1 member_tree">${String(e)}</span>`));
        });
        document.querySelectorAll('.member_tree').forEach(e => {
            e.addEventListener('click', event => {
                let tree_num = Number(event.target.innerText) - 1;
                publish("GenerateTreePlot", {
                    tree_id: tree_num,
                    div_id: 'affinity_tree'
                });
            });
        });

        el.scrollIntoView({ behavior: "smooth", block: "center", });
    }

    //D3.js Treemap charting
    let chart = function (data) {
        let width = 1000;
        let height = 1000;
        let color = d3.scaleSequential(d3.interpolateRainbow);//d3.scaleOrdinal(d3.schemeCategory10);
        let format = d3.format(",d");

        let treemap = data => d3.treemap()
            .tile(d3.treemapBinary)
            .size([width, height])
            .padding(1)
            .round(true)
            (d3.hierarchy(data)
                .sum(d => d.value)
                .sort((a, b) => b.value - a.value))

        const root = treemap(data);

        const svg = d3.create("svg")
            .attr("viewBox", [0, 0, width, height])
            .style("font", "10px sans-serif");

        const leaf = svg.selectAll("g")
            .data(root.leaves())
            .join("g")
            .attr("transform", d => `translate(${d.x0},${d.y0})`)
            .on('click', e => {
                build_member_list({ arr: e.data.members, name: e.data.name });
            });

        leaf.append("title")
            .text(d => `${d.ancestors().reverse().map(d => d.data.name).join("/")}\nNumber Trees: ${format(d.value)}`);

        leaf.append("rect")
            //.attr("id", d => (d.leafUid = DOM.uid("leaf")).id)
            .attr("fill", d => { while (d.depth > 1) d = d.parent; return color(d.value / 100.0); })
            .attr("fill-opacity", 0.6)
            .attr("width", d => d.x1 - d.x0)
            .attr("height", d => d.y1 - d.y0);

        leaf.append("clipPath")
            .attr("id", d => d.clipUid)
            .append("use")
        //.attr("xlink:href", d => d.leafUid.href);

        leaf.append("text")
            .attr("clip-path", d => d.clipUid)
            .selectAll("tspan")
            .data(d => d.data.name.split(/(?=[A-Z][a-z])|\s+/g).concat(format(d.value)))
            .join("tspan")
            .attr("x", 3)
            .attr("y", (d, i, nodes) => `${(i === nodes.length - 1) * 0.3 + 1.1 + i * 0.9}em`)
            .attr("fill-opacity", (d, i, nodes) => i === nodes.length - 1 ? 0.7 : null)
            .text(d => d);

        return svg.node();
    }

    let build_dom = function () {
        build_nodes_links(data_files.data_file.contents.splice(1));
        let treemap_data = build_treemap_data();
        let chartnode = chart(treemap_data);
        document.querySelector('#' + main_div + ' p').innerText = data_files.data_file.name;
        document.getElementById(main_div).setAttribute("style", "display:block");
        publish("ShowingVisualization", { name: "affinity" });
        document.getElementById(main_div).append(chartnode);
    }

    const init = function () {
        //Pub Sub Section
        let msg_guid = guid_func();
        const file_name_regex = /Affinity/;
        subscribe("AvailableFiles", data => {
            if (data.guid === msg_guid) {
                const regex = RegExp(file_name_regex);
                let coor_files = data.data.filter(f => {
                    return regex.test(f);
                });

                subscribe("FileContents", d => {
                    if (d.guid != msg_guid) {
                        return;
                    }
                    let df = {}
                    coor_files.forEach(k => {
                        if (k.endsWith("log")) {
                            df["log_file"] = {
                                "name": k,
                                "contents": d[k]
                            };
                        } else {
                            df["data_file"] =
                            {
                                "name": k,
                                "contents": d.files_object[k]
                            };
                        }
                    });
                    data_files = df;
                    build_dom();
                });
                if (coor_files.length > 0) {
                    publish("RequestFileContents", {
                        guid: msg_guid,
                        names: coor_files
                    });
                }
            }
        });
        publish("AvailableFilesRequest", { guid: msg_guid });
    };
    return { init };
}

export {
    plot_affinity_network
};