import { htmlToElement } from "./html_template.js";
/**
 * Create 2D and 3D scatterplots.
 * 
 * Looks for files with the name pattern:
 *  
 *  *_3D_*COR*.out AND *tree* 
 * 
 * The coordinate file and the newick tree file.
 *  
 */

let scatterplots = function (conf_oj) {
    const { subscribe, publish, two_d_dom, three_d_dom, main_div, guid_func } = conf_oj;
    let coordinate_data = undefined;

    let plot_plot = function (point_idx) {
        const dp = coordinate_data[point_idx];
        Plotly.addTraces(three_d_dom, { x: [dp[0]], y: [dp[1]], z: [dp[2]], type: 'scatter3d', marker: { size: 8 } });
        Plotly.addTraces(two_d_dom, { x: [dp[0]], y: [dp[1]], marker: { size: 8 } });
    }

    document.getElementById('show_2d').addEventListener('change', e => {
        if (e.target.checked) {
            let e1 = document.getElementById('three_d');
            e1.remove();
            build_dom({ all_plots: false });
        } else {
            let e1 = document.getElementById('three_d');
            let e2 = document.getElementById('two_d');
            e1.remove();
            e2.remove();
            build_dom({ all_plots: true });
        }
    });

    let build_dom = function (obj) {
        document.getElementById(main_div).setAttribute("style", "display:block");
        publish("ShowingVisualization", { name: "scatter" });
        let { all_plots } = obj;
        const elem = document.getElementById('low_dimension');
        if (all_plots) {
            let e = htmlToElement('<div id="three_d" class="col-12"></div>');
            elem.append(e);
            scatter_3d(coordinate_data);
        } else {
            let e = htmlToElement('<div id="three_d" class="col-6"></div>');
            let e2 = htmlToElement('<div id="two_d" class="col-6"></div>');
            elem.append(e);
            elem.append(e2);
            scatter_3d(coordinate_data);
            scatter_2d(coordinate_data);
        }
    }

    let scatter_2d = function (file_contents) {
        let axis_max_min = function (x_data, y_data) {
            const x_max = Math.max(...x_data);
            const y_max = Math.max(...y_data);
            const x_min = Math.min(...x_data);
            const y_min = Math.min(...y_data);
            return [Math.min(x_max, y_max, x_min, y_min), Math.max(x_max, y_max, x_min, y_min)];

        };
        let row_data = {
            x: [],
            y: []
        };
        file_contents.forEach(r => {
            row_data['x'].push(Number(r[0]));
            row_data['y'].push(Number(r[1]));
        });
        const trace1 = {
            x: row_data['x'],
            y: row_data['y'],
            click_mode: 'select',
            mode: 'markers',
            type: 'scatter',
            marker: { size: 5 }
        };
        const layout = {
            xaxis: {
                range: axis_max_min(row_data['x'], row_data['y'])
            },
            yaxis: {
                range: axis_max_min(row_data['x'], row_data['y'])
            },
        };

        const plot_2d = document.getElementById(two_d_dom);
        Plotly.newPlot(two_d_dom, [trace1], layout);

        plot_2d.on('plotly_click', function (event) {
            plot_plot(event.points[0].pointIndex)
        });
    }

    let scatter_3d = function (file_contents) {
        let row_data = {
            'x': [],
            'y': [],
            'z': []
        };
        file_contents.forEach(r => {
            row_data['x'].push(Number(r[0]));
            row_data['y'].push(Number(r[1]));
            row_data['z'].push(Number(r[2]));
        });
        const data = [{
            x: row_data['x'],
            y: row_data['y'],
            z: row_data['z'],
            mode: 'markers',
            type: 'scatter3d',
            marker: {
                symbol: 'circle',
                color: row_data['z'],
                size: 2
            },
            hovertemplate: "Data Point: %{pointNumber} <br> Coordinates: x: %{x} y: %{y} z: %{z}",

        },];
        const layout = {
            autosize: true,
            height: 800,
            scene: {
                aspectratio: {
                    x: 1.25,
                    y: 1.25,
                    z: 1.25
                },
                xaxis: {
                    type: 'linear',
                    zeroline: false
                },
                yaxis: {
                    type: 'linear',
                    zeroline: false
                }
            }
        };

        const btns = {
            displaylogo: false,
            modeBarButtonsToAdd: [
                [{
                    name: 'All points black',
                    icon: Plotly.Icons.pencil,
                    click: function () {
                        Plotly.restyle(three_d_dom, 'marker.color', ['black']);
                    }
                },
                {
                    name: 'Point color Z-axis',
                    icon: Plotly.Icons.pencil,
                    click: function () {
                        Plotly.restyle(three_d_dom, 'marker.color', [row_data['z']]);
                    }
                },
                {
                    name: 'Point color Y-axis',
                    icon: Plotly.Icons.pencil,
                    click: function () {
                        Plotly.restyle(three_d_dom, 'marker.color', [row_data['y']]);
                    }
                },
                {
                    name: 'Point color X-axis',
                    icon: Plotly.Icons.pencil,
                    click: function () {
                        Plotly.restyle(three_d_dom, 'marker.color', [row_data['x']]);
                    }
                },
                {
                    name: 'Enlarge Points',
                    icon: Plotly.Icons.pencil,
                    click: function (data) {
                        let curr_size = data.data[0].marker.size
                        Plotly.restyle(three_d_dom, 'marker.size', curr_size += 2);
                    }
                },
                {
                    name: 'Shrink Points',
                    icon: Plotly.Icons.pencil,
                    click: function (data) {
                        let curr_size = data.data[0].marker.size;
                        if (curr_size === 2) {
                            console.log('Nope, too small');
                        } else {
                            Plotly.restyle(three_d_dom, 'marker.size', curr_size -= 2);
                        }
                    }
                }
                ],
            ]
        }
        let s_plot = document.getElementById(three_d_dom);
        Plotly.newPlot(three_d_dom, data, layout, btns);
        s_plot.on("plotly_click", function (data) {
            let tree_idx = data.points[0]['pointNumber'] - 1;
            publish("GenerateTreePlot", {
                tree_id: tree_idx,
                div_id: "tree_of_interest"
            });
        });
    }

    let clean_data = function (files) {
        Object.keys(files).forEach(k => {
            coordinate_data = files[k].map(row => {
                return row.map(i => Number(i));
            });
        });
    }

    const init = function () {
        //Pub Sub Section
        const msg_guid = guid_func();
        const file_name_regex = "NLDR_Dim_3_Coordinates";
        subscribe("AvailableFiles", data => {
            if (data.guid === msg_guid) {
                const regex = RegExp(file_name_regex);
                let coor_files = data.data.filter(f => {
                    return regex.test(f);
                });

                subscribe("FileContents", d => {
                    if (d.guid === msg_guid) {
                        let df = {}
                        coor_files.forEach(k => {
                            df[k] = d.files_object[k];
                        });
                        clean_data(df);
                        build_dom({ all_plots: true });
                    }
                });
                if (coor_files.length > 0) {
                    publish("RequestFileContents", {
                        guid: msg_guid,
                        names: coor_files
                    });
                }
            }
        });
        publish("AvailableFilesRequest", { guid: msg_guid });
    }
    return { init };
}


export { scatterplots }