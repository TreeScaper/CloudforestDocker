import { htmlToElement } from "./html_template.js";

let parallel_coordinates = function (conf_obj) {
    const { subscribe, publish, guid_func, main_div } = conf_obj;
    let file_data = undefined; // Key: file name , value: file contents

    let rows_to_dimensions = function (row_data) {
        let dimension_data = {};
        row_data.forEach(row => {
            row.forEach((item, idx) => {
                let dim_name = `Dimension_${idx}`;
                if (Object.keys(dimension_data).indexOf(dim_name) === -1) {
                    dimension_data[dim_name] = [];
                }
                dimension_data[dim_name].push(item);
            });
        });
        return dimension_data;
    }

    let create_plot = function (data_obj) {
        let { file_name, f_data, dom_id } = data_obj;
        let dims = [];
        let dim_data = rows_to_dimensions(f_data);
        Object.keys(dim_data).forEach(k => {
            dims.push({
                range: [d3.min(dim_data[k]), d3.max(dim_data[k])],
                label: k,
                values: dim_data[k]
            })
        });
        let data = [{
            type: "parcoords",
            line: {
                showscale: false,
                colorscale: 'Jet',
                color: dim_data[Object.keys(dim_data)[0]]
            },
            dimensions: dims,
        }];
        let layout = {
            height: 800,
            width: 1200
        }
        Plotly.newPlot(dom_id, data, layout, {
            displaylogo: false,
        });
    }

    let build_dom = function () {
        document.getElementById(main_div).setAttribute("style", "display:block");
        publish("ShowingVisualization", { hrefname: "md-card", innername: "Multidimension Plots" });

        let elm_str = '<div>';

        Object.keys(file_data).forEach(fn => {
            elm_str += `<button class="button is-light is-link nldr-btns" value="${fn}">${fn}</button>`
        });

        elm_str += '</div>';

        document.getElementById("file-buttons").append(htmlToElement(elm_str));
        let btns = document.getElementsByClassName('nldr-btns');
        for (let i = 0; i < btns.length; i++) {
            btns[i].addEventListener('click', event => {
                console.log(event.target.value);
                create_plot({
                    file_name: event.target.value,
                    f_data: file_data[event.target.value],
                    dom_id: "md_p"
                });
            });
        }
        document.querySelector('#' + main_div + ' div.card-content').append(htmlToElement('<div id="md_p"/>'));
        //let plot_elem = document.getElementById(main_div).append(htmlToElement('<div id="md_p" class="column is-centered"/>'));
        publish("ModuleLoaded", {});
    }

    const init = function () {
        //Pub Sub Section
        let msg_guid = guid_func();
        const file_name_regex = /Dim_.*_Coordinates/; // NB: Will cover all dimension files.
        subscribe("AvailableFiles", data => {
            if (data.guid === msg_guid) {
                const regex = RegExp(file_name_regex);
                let coor_files = data.data.filter(f => {
                    return regex.test(f);
                });

                subscribe("FileContents", d => {
                    if (d.guid != msg_guid) {
                        return;
                    }
                    let df = {}
                    coor_files.forEach(k => {
                        df[k] = d.files_object[k].map(row => {
                            return row.map(i => Number(i));
                        });
                    });
                    file_data = df;
                    build_dom();
                });
                if (coor_files.length > 0) {
                    publish("RequestFileContents", {
                        guid: msg_guid,
                        names: coor_files
                    });
                } else {
                    publish("ModuleLoaded", {}); // no files or interest, publish and forget
                }
            }
        });
        publish("AvailableFilesRequest", { guid: msg_guid });
    };

    return { init };
}

export { parallel_coordinates }