import { galaxy_data_provider } from "./js/modules/galaxy_data.js";
// import { local_data } from "./js/modules/data_source.js";
import { scatterplots } from "./js/modules/scatter_plots.js";
import { parallel_coordinates } from "./js/modules/multidimension.js";
//import { plot_affinity_network } from "./js/modules/affinity.js";
import { plot_affinity_graph } from "./js/modules/affinity_graph.js";
import { bipartition_bar_chart } from "./js/modules/bipartition.js";
import { phylogram } from "./js/modules/phylogram.js";
import { htmlToElement } from "./js/modules/html_template.js";

let CloudForest = function (config) {
    let { dataName, historyID, datasetID, dom_base, href, dbkey } = config;

    let events = {};
    let event_debug = false;

    let subscribe = function (event, fn) {
        if (!events[event]) {
            events[event] = [];
        }
        events[event].push({
            callback: fn
        });
    };

    let publish = function (event, args = undefined) {
        if (!events[event]) {
            return false;
        }
        if (event_debug) {
            console.log(`APP PUBLISH: ${event}`);
        }
        events[event].map(function (cv) {
            let subscription = cv;
            subscription.callback(args);
        });
    };

    let nav_enable = function (data) {
        const nav_dropdown = document.getElementById("plot-navigation");
        nav_dropdown.append(htmlToElement(`<a href="#${data['hrefname']}" class="navbar-item">${data['innername']}</a>`));
    }

    let show_progress = function (pct) {
        let e = document.getElementById("loading-progress");
        e.value = String(pct);
        if (pct >= 100) {
            e.setAttribute("style", "display: none;")
        }
    }

    let get_guid = function () {
        let array = new Uint32Array(2);
        window.crypto.getRandomValues(array);
        let msg_guid = array.join('');
        return msg_guid;
    }

    const PLOT_MODULES = 5; // Importing and activatinf five plotting modules

    let run = function () {
        let module_progress = 0;

        subscribe("ModuleLoaded", function (data) {
            module_progress += 1;
            show_progress((100 / PLOT_MODULES) * module_progress);
        });

        subscribe("ShowingVisualization", function (data) {
            nav_enable(data);
        });

        const phylogram_plts = phylogram({
            subscribe: subscribe,
            publish: publish,
            guid_func: get_guid
        });

        const scatter_plts = scatterplots({
            subscribe: subscribe,
            publish: publish,
            two_d_dom: "two_d",
            three_d_dom: "three_d",
            main_div: "scatter_plots",
            guid_func: get_guid,
        });

        const multidimension_plots = parallel_coordinates({
            subscribe: subscribe,
            publish: publish,
            main_div: "md-card",
            guid_func: get_guid
        });

        const affinity_plots = plot_affinity_graph({
            subscribe: subscribe,
            publish: publish,
            main_div: "affinity-card",
            guid_func: get_guid
        });

        const bp_chart = bipartition_bar_chart({
            subscribe: subscribe,
            publish: publish,
            main_div: "bipart-card",
            guid_func: get_guid

        });

        subscribe('DataPrimed', d => {
            phylogram_plts.init();
            scatter_plts.init();
            multidimension_plots.init();
            affinity_plots.init();
            bp_chart.init();
        });

        let data_source = galaxy_data_provider({
            href: href,
            subscribe: subscribe,
            publish: publish,
            data_name: dataName,
            history_id: historyID,
            dataset_id: datasetID
        });
        data_source.init()

    }

    return {
        run
    };

}

export { CloudForest }  