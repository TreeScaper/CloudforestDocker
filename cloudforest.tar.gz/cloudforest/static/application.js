import { galaxy_data_provider } from "./js/modules/galaxy_data.js";
import { scatterplots } from "./js/modules/scatter_plots.js";
import { parallel_coordinates } from "./js/modules/multidimension.js";
import { plot_affinity_network } from "./js/modules/affinity.js";
import { bipartition_bar_chart } from "./js/modules/bipartition.js";
import { phylogram } from "./js/modules/phylogram.js";

let CloudForest = function (config) {
    let { dataName, historyID, datasetID, dom_base } = config;

    let events = {};
    let event_debug = false;

    let subscribe = function (event, fn) {
        if (!events[event]) {
            events[event] = [];
        }
        events[event].push({
            callback: fn
        });
    };

    let publish = function (event, args = undefined) {
        if (!events[event]) {
            return false;
        }
        if (event_debug) {
            console.log(`APP PUBLISH: ${event}`);
        }
        events[event].map(function (cv) {
            let subscription = cv;
            subscription.callback(args);
        });
    };

    let nav_enable = function (item_name) {
        const nav_item = document.getElementById(`${item_name}_link`);
        nav_item.setAttribute("aria-disabled", "false");
        nav_item.classList.remove("disabled");
    }

    let get_guid = function () {
        let array = new Uint32Array(2);
        window.crypto.getRandomValues(array);
        let msg_guid = array.join('');
        return msg_guid;
    }

    let run = function () {

        subscribe("ShowingVisualization", function (data) {
            nav_enable(data.name);
        });

        const phylogram_plts = phylogram({
            subscribe: subscribe,
            publish: publish,
            guid_func: get_guid
        });

        const scatter_plts = scatterplots({
            subscribe: subscribe,
            publish: publish,
            two_d_dom: "two_d",
            three_d_dom: "three_d",
            main_div: "scatter_plots",
            guid_func: get_guid,
        });

        const multidimension_plots = parallel_coordinates({
            subscribe: subscribe,
            publish: publish,
            main_div: "multidimension_plots",
            guid_func: get_guid
        });

        const affinity_plots = plot_affinity_network({
            subscribe: subscribe,
            publish: publish,
            main_div: "affinity_plots",
            guid_func: get_guid
        });

        const bp_chart = bipartition_bar_chart({
            subscribe: subscribe,
            publish: publish,
            main_div: "bipartition_plots",
            guid_func: get_guid

        });

        subscribe('DataPrimed', d => {
            phylogram_plts.init();
            scatter_plts.init();
            multidimension_plots.init();
            affinity_plots.init();
            bp_chart.init();
        });

        let data_source = galaxy_data_provider({
            subscribe: subscribe,
            publish: publish,
            data_name: dataName,
            history_id: historyID,
            dataset_id: datasetID
        });
        data_source.init()

    }

    return {
        run
    };

}

export { CloudForest }  